# Hospital Appointment Booking — Exercise 8

This project is a Camunda 8 BPMN/DMN implementation based on the supplied Exercise-8.pdf.

## Project files
- `bpmn/hospital-appointment-booking.bpmn` — parent booking process, DMN task, gateway, three call activities, and non-interrupting cancellation event subprocess.
- `bpmn/send-notification.bpmn` — reusable child process with a Telegram REST Outbound Connector task.
- `dmn/slot_decision.dmn` — UNIQUE-hit-policy slot decision table.
- `test-payloads/` — example variables and cancellation message payload.
- `docs/` — mapping and deployment notes.

## Import and deploy
1. Open Camunda Modeler (compatible Camunda 8 release).
2. Import both BPMN files and the DMN file.
3. Deploy all three resources to the same Camunda 8 cluster.
4. In the cluster's Secrets configuration, create `TELEGRAM_BOT_TOKEN`. Do not commit the real token to GitHub.
5. Confirm the REST Outbound Connector is available in the runtime.
6. Start `hospital-appointment-booking` with one of the JSON variable sets in `test-payloads/`.
7. For cancellation, publish the message `Cancel booking` with correlation key equal to the booking's `patientId`. The event subprocess is non-interrupting, so the main process is not cancelled.

## Important implementation notes
- All call activities explicitly disable automatic child-variable propagation and map only `recipientId` and `messageText`.
- The child process expects `recipientId` to be a Telegram chat ID, not necessarily a hospital patient database ID. For a real Telegram integration, pass/store the patient's Telegram chat ID in a variable and map that to `recipientId`.
- The cancellation task `Release slot` is a workflow placeholder. Connect it to the hospital's actual scheduling/database service before production use.
- The DMN example uses a threshold of 10 for Cardiology and 15 for other departments. Only the Cardiology threshold is specified by the assignment; the 15-booking threshold for other departments is an explicit example assumption and can be changed.
- The assignment requests Operate screenshots and live deployment tests. These cannot be truthfully supplied by static project files; capture them after deploying and running the project in your own Camunda environment.

## Suggested GitHub submission
Commit the full folder, excluding real credentials, generated logs, and any private patient data.
