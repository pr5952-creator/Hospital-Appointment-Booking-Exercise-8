# Input/output mappings and variable propagation

Every parent call activity maps:
- `patientId` -> child `recipientId`
- a process-generated confirmation/full/cancellation string -> child `messageText`

Each call activity sets `propagateAllChildVariables="false"`. This prevents child process variables and connector response data from being copied back into the parent. Only the two explicitly mapped inputs are sent to the child.

If propagation is enabled, all parent variables are made available to the child and child outputs can be propagated back, which is convenient but exposes unnecessary data and can create variable collisions. Explicit mapping with propagation disabled is safer and matches the exercise's requested final behaviour.

## Cancellation correlation
Publish a message named `Cancel booking` with correlation key equal to `patientId`. The event subprocess uses a non-interrupting message start event so cancellation handling can run alongside the parent flow. `Release slot` is a placeholder task and must be connected to a real slot-management implementation for an operational system.
