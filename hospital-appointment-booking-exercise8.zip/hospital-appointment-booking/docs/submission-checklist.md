# Submission checklist

- [ ] Import and validate both BPMN models in Camunda Modeler.
- [ ] Import and validate `slot_decision.dmn`.
- [ ] Configure the `TELEGRAM_BOT_TOKEN` secret in Camunda (never commit the token).
- [ ] Deploy parent BPMN, child BPMN, and DMN.
- [ ] Test Cardiology with `bookedCount = 3`.
- [ ] Test Cardiology with `bookedCount = 12`.
- [ ] Complete a successful booking, then correlate a `Cancel booking` message using the same `patientId`.
- [ ] Capture Operate screenshots: parent instance, linked child instance, and cancellation path.
- [ ] Add screenshots to a `screenshots/` folder before final classroom submission.
